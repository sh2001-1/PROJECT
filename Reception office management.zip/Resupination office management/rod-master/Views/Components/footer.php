<!-- Footer -->
<div class="lightAccentBack">
    <div class="container">
        <div class="d-md-flex justify-content-between align-items-center py-3">
            <div class="d-flex align-items-center">
                <div>
                    <p class="text-dark-emphasis align-self-center m-0">&copy;2023 <span class="fw-bold">St. Francis
                            College
                            for
                            Women</span></p>
                </div>
            </div>

            <div class="mt-3 mt-md-0">
                <a class="text-body-tertiary baseHover pe-2" href="https://www.instagram.com/st.franciscollegeforwomen/"><i class="fa-brands fa-instagram"></i></a>
                <a class="text-body-tertiary baseHover pe-2" href="https://www.youtube.com/@st.franciscollegeforwomena6644"><i class="fa-brands fa-youtube"></i></a>
                <a class="text-body-tertiary baseHover" href="https://www.facebook.com/stfranciscollege/"><i class="fa-brands fa-facebook"></i></a>
            </div>
        </div>
    </div>
</div>

<?php include $absoluteDir . "views/components/chatbot.php"; ?>
</body>

</html>